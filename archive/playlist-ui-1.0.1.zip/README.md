# Playlist UI for FoundryVTT
This module adds small improvements to the playlist tab inside FoundryVTT. The improvements are listed below.

## Filter by searching
The module adds a search bar at the top of the playlist tab that filters down the songs to match the search query. Filtering only begins once you have typed 3+ characters. Once you hit the play button, the playlist resets.
